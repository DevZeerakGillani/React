import React from "react";
import Setup from "./tutorial/11-memo-useMemo-useCallback/setup";

function App() {
  return (
    <div className="container">
      <Setup />
    </div>
  );
}

export default App;
