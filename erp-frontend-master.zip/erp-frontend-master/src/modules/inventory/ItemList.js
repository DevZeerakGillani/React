import React from 'react'

const ItemList = (props) => {
    return(
        <div>
            {children}
        </div>
    )
}

export default ItemList