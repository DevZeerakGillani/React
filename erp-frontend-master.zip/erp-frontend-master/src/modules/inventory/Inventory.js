import React, { Component } from 'react'
import Axios from 'axios'

class Inventory extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {}

  render() {
    return (
      <div className="">
        Inventory
      </div>
    );
  }
}

export default Inventory;
