import React from 'react'

const KitShow = (props) => {
    return(
        <div>
            
        </div>
    )
}

export default KitShow