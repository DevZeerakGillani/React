import React, {Component} from 'react';
import Axios from 'axios';

class Kit extends Component {

    render() {
        return '';
    }
}

export default Kit;
