import React from 'react'

const Navbar = (props) => {
    return(
        <div>
            {props.children}
        </div>
    )
}

export default Navbar