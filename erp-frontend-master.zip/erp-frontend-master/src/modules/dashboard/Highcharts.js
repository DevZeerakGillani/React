import React from 'react'

export const Highcharts = (props) => (
    <div>
        {children}
    </div>
)

export default Highcharts