import Chart from "./Chart.js";
import './App.css';

function App() {
  return (
    <div className="App">
      <Chart />
    </div>
  );
}

export default App;
